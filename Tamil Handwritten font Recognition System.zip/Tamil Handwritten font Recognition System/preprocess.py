# === Step 2: Preprocess Kaggle Tamil Dataset ===
# Requirements: tensorflow, numpy, PIL, sklearn
# pip install tensorflow numpy pillow scikit-learn

import os
from pathlib import Path
from PIL import Image
import numpy as np
from sklearn.model_selection import train_test_split
import shutil

# --- User Config ---
DATASET_PATH = "E:/mlproject/m_train"       # original Kaggle train folder
OUTPUT_PATH = "E:/mlproject/forcnn"  # preprocessed output folder
IMG_SIZE = (64, 64)
VAL_RATIO = 0.2
# -----------------------

DATASET_PATH = Path(DATASET_PATH)
OUTPUT_PATH = Path(OUTPUT_PATH)

# Create train/val folders
(train_dir := OUTPUT_PATH / "train").mkdir(parents=True, exist_ok=True)
(val_dir := OUTPUT_PATH / "val").mkdir(parents=True, exist_ok=True)

# Get all classes (folder names)
classes = [f.name for f in DATASET_PATH.iterdir() if f.is_dir()]
print("Classes found:", classes)

for cls in classes:
    cls_folder = DATASET_PATH / cls
    images = list(cls_folder.glob("*"))
    train_images, val_images = train_test_split(images, test_size=VAL_RATIO, random_state=42)
    
    # Create class folders in train and val
    (train_cls_dir := train_dir / cls).mkdir(parents=True, exist_ok=True)
    (val_cls_dir := val_dir / cls).mkdir(parents=True, exist_ok=True)
    
    # Copy and resize images
    for img_path in train_images:
        img = Image.open(img_path).convert("RGB").resize(IMG_SIZE)
        img.save(train_cls_dir / img_path.name)
    for img_path in val_images:
        img = Image.open(img_path).convert("RGB").resize(IMG_SIZE)
        img.save(val_cls_dir / img_path.name)

print("Preprocessing complete!")
print("Train folder:", train_dir)
print("Validation folder:", val_dir)
