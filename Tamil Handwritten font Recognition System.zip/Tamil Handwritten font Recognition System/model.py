from tensorflow.keras.models import load_model

# Load the saved model
model = load_model("E:/mlproject/tamil_cnn_model.h5")
# After training your model
model.save("E:/mlproject/tamil_cnn_model.h5")

print("Model saved successfully!")
