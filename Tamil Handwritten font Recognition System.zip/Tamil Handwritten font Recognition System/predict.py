# 1️⃣ Import necessary libraries
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# 2️⃣ Load your trained CNN model FIRST
model = load_model("E:/mlproject/tamil_cnn_model.h5")

# 3️⃣ Path to your test image
img_path = r"E:\mlproject\m_test\0012.png"  # use raw string r""

# 4️⃣ Load image and preprocess
img = image.load_img(img_path, target_size=(64,64))
img_array = image.img_to_array(img) / 255.0  # normalize
img_array = np.expand_dims(img_array, axis=0)  # add batch dimension

# 5️⃣ Prepare class labels
class_labels = sorted([f.name for f in Path("E:/mlproject/forcnn/train").iterdir() if f.is_dir()])

# 6️⃣ Predict
pred = model.predict(img_array)
pred_class_index = np.argmax(pred)
predicted_label = class_labels[pred_class_index]

# 7️⃣ Print prediction
print("Predicted Tamil letter:", predicted_label)

# 8️⃣ Show image with prediction
plt.imshow(img)
plt.title(f"Predicted: {predicted_label}")
plt.axis("off")
plt.show()
